﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EggCrack
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool canClick = true;

        public MainWindow()
        {
            InitializeComponent();
            Storyboard juju = (Storyboard)Resources["juju"];
            Storyboard rolling = (Storyboard)Resources["EggRoll"];
            Storyboard poking = (Storyboard)Resources["poking"];
            Storyboard rotten = (Storyboard)Resources["gudetama"];
            Storyboard falling = (Storyboard)Resources["falling"];
            Storyboard drop = (Storyboard)Resources["drop"];
            Storyboard chill = (Storyboard)Resources["chilling"];
            Storyboard stop = (Storyboard)Resources["stop"];

            rolling.Begin();

            //Keyboard handler to close the window when Escape key is pressed.
            KeyUp += (s, e) =>
            {
                if (e.Key == Key.Escape)
                {
                    Close();
                }
            };
            
            gude.MouseLeftButtonUp += (s, e) =>
            {
                if (canClick)
                {
                    canClick = false;
                    gude.Cursor = Cursors.Arrow;
                    rolling.Begin();


                }
            };

           
            gude.MouseEnter += (s, e) =>
            {
                juju.Begin();
                rolling.Begin();
                Console.WriteLine("HEllo");

            };

        }
    }
}
