To run the Arduino code, ensure that you have correctly connected everything.
Make note that the speaker needs to be connected to Pin 11.

In the Arduino IDE, install the damellis PCM library, this enables Arduino to play the PCM (.wav) sound of the person screaming. Without the .zip library, the code will not run. 

PCM.txt is the numerical form of person-scream.mp3/.wav

Happy Crafting!