package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.content.Intent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private AnimationDrawable animation;
    private ImageView imageView;
    private TranslateAnimation translateAnimation;
    int count = 0;
    Boolean men = false;
    private GestureDetectorCompat mDetector;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sprite);
        setTitle("firstSprite");
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        String title = (String) getTitle();
        if (title == "firstSprite") {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    setContentView(R.layout.coke);
                    setTitle("firstCoke");
                    break;
                case MotionEvent.ACTION_UP:
                    if(men==true){
                        men = false;
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    setContentView(R.layout.mentos);
                    imageView = findViewById(R.id.imageView27);
                    startTranslate();
                    men = true;
                    break;
                case MotionEvent.ACTION_CANCEL:
                    break;
            }
            return super.onTouchEvent(event);
        }
        if(title == "firstCoke") {
            switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                setContentView(R.layout.drpepper);
                setTitle("firstdrpepper");
                break;
            case MotionEvent.ACTION_UP:
                if(men==true){
                    ImageView imgView = findViewById(R.id.imageView14);
                    imgView.setBackgroundResource(R.drawable.animation_list);
                    animation = (AnimationDrawable)imgView.getBackground();
                            if(animation.isRunning()){
                                animation.stop();
                            }
                            animation.start();
                    men = false;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                setContentView(R.layout.mentos);
                imageView = findViewById(R.id.imageView27);
                startTranslate();
                men = true;
                break;
            case MotionEvent.ACTION_CANCEL:
                break;
        }
        return super.onTouchEvent(event);
        }

        if (title == "firstdrpepper") {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    setContentView(R.layout.sprite);
                    setTitle("firstSprite");

                    break;
                case MotionEvent.ACTION_UP:
                    if(men==true){
                        setContentView(R.layout.camera);
                        men = false;
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    setContentView(R.layout.mentos);
                    imageView = findViewById(R.id.imageView27);
                    startTranslate();

                    break;
                case MotionEvent.ACTION_CANCEL:
                    break;
            }
            return super.onTouchEvent(event);
        }

        return false;
    }

    private void startTranslate(){
        translateAnimation = new TranslateAnimation(Animation.ABSOLUTE,0.0f,Animation.ABSOLUTE, 0.0f,
                Animation.ABSOLUTE, 0.0f,
                Animation.ABSOLUTE, 250.0f );
        translateAnimation.setDuration(1500);
        translateAnimation.setFillAfter(true);
        imageView.startAnimation(translateAnimation);
        men = true;

    }

}


