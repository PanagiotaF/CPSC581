package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.graphics.drawable.AnimationDrawable;
import android.media.Image;
import android.os.Bundle;
import android.content.Intent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private AnimationDrawable animation;
    private ImageView imageView;
    private TranslateAnimation translateAnimation;
    int count = 0;
    Boolean men = false;
    private GestureDetectorCompat mDetector;
    // for the sensors
    private SensorManager sensorManager;
    private long lastUpdate;
    private int clickCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coke);


        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        lastUpdate = System.currentTimeMillis();
        checkCan();
    }

    @Override
    public void onSensorChanged(SensorEvent event){
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            getAccelerometer(event);
        }
    }
    private void getAccelerometer(SensorEvent event){
        float[] values = event.values;

        //when the phone is moved
        float x = values[0];
        float y = values[1];
        float z = values[2];

        float accelerationSquareRoot = (x*x + y*y + z*z)/(SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
        long actualTime = event.timestamp;
        // shake all around
        if (accelerationSquareRoot >=2){
            if(actualTime - lastUpdate <200){
                return;
            }
            lastUpdate=actualTime;
            //handle shaking code here
            sprite.setVisibility(View.VISIBLE);
            drpepper.setVisibility(View.INVISIBLE);
            cokecan.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy){

    }
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause(){
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    public void checkCan(){
        ImageView cokecan = (ImageView) findViewById(R.id.cocacola);
        ImageView sprite = (ImageView) findViewById(R.id.sprite);
        ImageView drpepper = (ImageView) findViewById(R.id.drpepper);

        cokecan.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                clickCount++;
                if(clickCount == 1){
                    sprite.setVisibility(View.VISIBLE);
                    drpepper.setVisibility(View.INVISIBLE);
                    cokecan.setVisibility(View.INVISIBLE);
                } else if(clickCount ==2){
                    sprite.setVisibility(View.INVISIBLE);
                    drpepper.setVisibility(View.VISIBLE);
                    cokecan.setVisibility(View.INVISIBLE);

                }else if(clickCount ==3){
                    clickCount=0;
                    sprite.setVisibility(View.INVISIBLE);
                    drpepper.setVisibility(View.INVISIBLE);
                    cokecan.setVisibility(View.VISIBLE);

                }
            }
        });
    }
 /*   @Override
    public boolean onTouchEvent(MotionEvent event) {
        String title = (String) getTitle();
        if (title == "firstSprite") {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    setContentView(R.layout.coke);
                    setTitle("firstCoke");
                    break;
                case MotionEvent.ACTION_UP:
                    if(men==true){
                        men = false;
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    setContentView(R.layout.mentos);
                    imageView = findViewById(R.id.imageView27);
                    startTranslate();
                    men = true;
                    break;
                case MotionEvent.ACTION_CANCEL:
                    break;
            }
            return super.onTouchEvent(event);
        }
        if(title == "firstCoke") {
            switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                setContentView(R.layout.drpepper);
                setTitle("firstdrpepper");
                break;
            case MotionEvent.ACTION_UP:
                if(men==true){
                    ImageView imgView = findViewById(R.id.imageView14);
                    imgView.setBackgroundResource(R.drawable.animation_list);
                    animation = (AnimationDrawable)imgView.getBackground();
                            if(animation.isRunning()){
                                animation.stop();
                            }
                            animation.start();
                    men = false;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                setContentView(R.layout.mentos);
                imageView = findViewById(R.id.imageView27);
                startTranslate();
                men = true;
                break;
            case MotionEvent.ACTION_CANCEL:
                break;
        }
        return super.onTouchEvent(event);
        }

        if (title == "firstdrpepper") {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    setContentView(R.layout.sprite);
                    setTitle("firstSprite");

                    break;
                case MotionEvent.ACTION_UP:
                    if(men==true){
                        setContentView(R.layout.camera);
                        men = false;
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    setContentView(R.layout.mentos);
                    imageView = findViewById(R.id.imageView27);
                    startTranslate();

                    break;
                case MotionEvent.ACTION_CANCEL:
                    break;
            }
            return super.onTouchEvent(event);
        }

        return false;
    }

    private void startTranslate(){
        translateAnimation = new TranslateAnimation(Animation.ABSOLUTE,0.0f,Animation.ABSOLUTE, 0.0f,
                Animation.ABSOLUTE, 0.0f,
                Animation.ABSOLUTE, 250.0f );
        translateAnimation.setDuration(1500);
        translateAnimation.setFillAfter(true);
        imageView.startAnimation(translateAnimation);
        men = true;

    }*/

}


